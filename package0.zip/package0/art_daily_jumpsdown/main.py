import random as rn
import pandas as pd
from shingle import shingle
import numpy as np
import time
import eif_vnif as iso_eif_vnif
import HS_forest as iso_HS
import rrcf
from pandas import DataFrame
from sklearn import metrics

X2=pd.read_csv('art_daily_jumpsdown_2500.csv')
X2=np.array([X2.value]).T
X2_norm0 = (X2.T[0]-X2.T[0].min())/(X2.T[0].max()-X2.T[0].min())
X2_norm  = np.c_[X2_norm0,X2_norm0,X2_norm0]

X1=pd.read_csv('art_daily_jumpsdown_all.csv')
X1=np.array([X1.value]).T
X1_norm0 = (X1.T[0]-X2.T[0].min())/(X2.T[0].max()-X2.T[0].min())
X1_norm  = np.c_[X1_norm0,X1_norm0,X1_norm0]

data_dim = 4
data_stream = shingle(X1_norm0,data_dim)
X_shingle = np.asarray(next(data_stream))
for i in range(1, len(X1_norm0) - data_dim + 1):
    X_shingle = np.vstack((X_shingle, next(data_stream)))

Nobjs = X2.shape[0]
Nobjs1 = X1.shape[0]                                              #
ntrees=50
ntrees1=5000
sample = 256
sample0 = 64
CT=[]
c = iso_eif_vnif.c_factor(sample)
S_eif_vnif = []
S_eif_vnif_shingle = []
S_HS = np.zeros(Nobjs1)
#setting finished

#eif_vnif scoring
time_start = time.time()
F_eif_vnif = iso_eif_vnif.iForest(X2_norm,ntrees=50, sample_size=sample, ExtensionLevel=2)          #
S_eif_vnif = F_eif_vnif.compute_paths(X_in=X1_norm)                                                #
time_end = time.time()
print ('eif_vnif totally cost ',time_end-time_start)
# eif_vnif finished

# eif_vnif with shingle scoring
time_start=time.time()
for n in range (len(X_shingle)-sample-2):
    F1 = iso_eif_vnif.iForest(X_shingle[n:n+sample],ntrees=50, sample_size=sample0, ExtensionLevel=3)
    S1 = F1.compute_paths(X_in=X_shingle[n+sample+1:n+sample+2])
    S_eif_vnif_shingle.append(S1)
time_end = time.time()
print('eif_vnif with shingle cost: ',time_end-time_start)
# eif_vnif finished

# HS-Tree scoring
time_start = time.time()
CT = []
for i in range(ntrees):
    ix = rn.sample(range(Nobjs),sample)
    X_p = X2_norm[ix]                                                              #
    limit = 10
    C_if=iso_HS.iTree(X_p,0,limit)
    CT.append(C_if)
for i in range(Nobjs1):
    h_temp = 0
    for j in range(ntrees):
        h_temp += iso_HS.PathFactor(X1_norm[i],CT[j]).path*1.01                 #
    Eh = h_temp/ntrees
    S_HS[i] = 2.0**(-Eh/c)
time_end = time.time()
print ('HS-Tree totally cost ',time_end-time_start)
# HS-Tree finished

# rrcf scoring
parmas = {"trees" : 100}
sample_size = 256
data_dim = 4
data = X1_norm0
data_shingle = X_shingle
time_start = time.time()
forest = [rrcf.RCTree(X_shingle[0:3,:]) for i in range(0, parmas["trees"])]
# add 3 data points
data_index = [0, 1, 2]
codisp = np.zeros((len(X1_norm0), parmas["trees"]))                                          #*************

for tree in forest:
    codisp[1, forest.index(tree)] = tree.codisp(1)
    codisp[2, forest.index(tree)] = tree.codisp(2)

for i in range(3, len(X_shingle)):
    if len(data_index) >= sample_size:
        # forget the point
        for tree in forest:
            tree.forget_point(data_index[0])
        data_index.pop(0)

    data_index.append(i+3)
    # insert the new point
    d = X_shingle[i]
    for tree in forest:
        tree.insert_point(np.asarray(d), data_index[-1])
        # compute the codisp
        codisp[i, forest.index(tree)] = tree.codisp(data_index[-1])
time_end = time.time()
print ('rrcf totally cost ',time_end-time_start)
# rrcf finished

S_eif_vnif_pd =DataFrame(S_eif_vnif,columns=['eif_vnif_score'])
zero=DataFrame(np.ones((261,1))*0)
S_eif_vnif_shingle_pd=DataFrame(S_eif_vnif_shingle)
S=pd.concat([zero,S_eif_vnif_shingle_pd],axis=0,ignore_index=1)
S.columns=['eif_vnif_shingle_score']
S_HS_pd = DataFrame(S_HS,columns=['HS_Tree_score'])
S_rrcf_pd = DataFrame(codisp.mean(axis=1),columns=['rrcf_score'])

jumpsdown_score = pd.concat([S_eif_vnif_pd,S,S_HS_pd,S_rrcf_pd],axis=1)              #
jumpsdown_score.to_csv('art_daily_jumpsdown_score.csv')                                #

Y1 = pd.read_csv('art_daily_jumpsdown_all.csv')
Y2 = pd.read_csv('art_daily_jumpsdown_score.csv')
label = np.array(Y1.label)
S_eif_vnif_score = np.array(Y2.eif_vnif_score)
eif_vnif_shingle_score = np.array(Y2.eif_vnif_shingle_score)
HS_Tree_score = np.array(Y2.HS_Tree_score)
rrcf_score = np.array(Y2.rrcf_score)

fpr1,tpr1,thresholds = metrics.roc_curve(label,S_eif_vnif_score,pos_label=1)
fpr2,tpr2,thresholds = metrics.roc_curve(label,eif_vnif_shingle_score,pos_label=1)
fpr3,tpr3,thresholds = metrics.roc_curve(label,HS_Tree_score,pos_label=1)
fpr4,tpr4,thresholds = metrics.roc_curve(label,rrcf_score,pos_label=1)

auc1=metrics.auc(fpr1,tpr1)
auc2=metrics.auc(fpr2,tpr2)
auc3=metrics.auc(fpr3,tpr3)
auc4=metrics.auc(fpr4,tpr4)

print('eif_vnif',auc1)
print('eif_vnif_shingle',auc2)
print('HS_Tree',auc3)
print('rrcf',auc4)

roc1=pd.DataFrame(fpr1)
roc2=pd.DataFrame(tpr1)
roc3=pd.DataFrame(fpr2)
roc4=pd.DataFrame(tpr2)
roc5=pd.DataFrame(fpr3)
roc6=pd.DataFrame(tpr3)
roc7=pd.DataFrame(fpr4)
roc8=pd.DataFrame(tpr4)

roc = pd.concat([roc1,roc2,roc3,roc4,roc5,roc6,roc7,roc8],axis=1)
roc.to_csv('jumpsdown_roc.csv')
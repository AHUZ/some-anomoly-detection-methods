import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sklearn
from sklearn.ensemble import IsolationForest
import sklearn.metrics as met
import rrcf
from shingle import shingle

X2 = pd.read_csv('art_daily_flatmiddle_2500.csv')
X2 = np.array([X2.value]).T
X2_norm0 = (X2.T[0] - X2.T[0].min()) / (X2.T[0].max() - X2.T[0].min())
X2_norm = np.c_[X2_norm0, X2_norm0, X2_norm0]

X1 = pd.read_csv('art_daily_flatmiddle_all.csv')
X1 = np.array([X1.value]).T
X1_norm0 = (X1.T[0] - X2.T[0].min()) / (X2.T[0].max() - X2.T[0].min())

data_dim = 4
data_stream = shingle(X1_norm0, data_dim)
sin_shingle = np.asarray(next(data_stream))

for i in range(1, len(X1_norm0) - data_dim + 1):
    sin_shingle = np.vstack((sin_shingle, next(data_stream)))

parmas = {"trees": 100}
data_dim = 4
data_index = []
data = X1_norm0
data_shingle = sin_shingle
sample_size = 256

# make the inital trees
forest = [rrcf.RCTree(sin_shingle[0:3, :]) for i in range(0, parmas["trees"])]
# add 3 data points
data_index = [0, 1, 2]
codisp = np.zeros((len(X1_norm0), parmas["trees"]))  # *************

for tree in forest:
    codisp[1, forest.index(tree)] = tree.codisp(1)
    codisp[2, forest.index(tree)] = tree.codisp(2)

for i in range(3, len(sin_shingle)):
    if len(data_index) >= sample_size:
        # forget the point
        for tree in forest:
            tree.forget_point(data_index[0])
        data_index.pop(0)

    data_index.append(i + 3)
    # insert the new point
    d = sin_shingle[i]
    for tree in forest:
        tree.insert_point(np.asarray(d), data_index[-1])
        # compute the codisp
        codisp[i, forest.index(tree)] = tree.codisp(data_index[-1])

# In[8]:


fig, ax1 = plt.subplots()

colorY1 = 'tab:red'
ax1.set_ylabel('Sine wave', color=colorY1)
ax1.plot(data, color=colorY1)
ax1.tick_params(axis='y', labelcolor=colorY1)
ax1.set_ylim(0., 160.)

ax2 = ax1.twinx()

colorY2 = 'tab:blue'
ax2.set_ylabel('Anomaly score', color=colorY2)
ax2.plot(codisp.mean(axis=1) / max(codisp.mean(axis=1)), color=colorY2)
ax2.tick_params(axis='y', labelcolor=colorY2)
ax2.set_ylim(0.0, 2)

fig.tight_layout()
plt.show()
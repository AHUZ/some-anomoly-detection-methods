"virtual node isolated forest functions"
__author__ = 'Matias Carrasco Kind && Qi Xing && Zi-Dong Zhou'
import numpy as np
from scipy.stats import multivariate_normal
import random as rn
import pandas as pd
from pandas import DataFrame
from sklearn import metrics
import time
import eif_vnif as iso_eif_vnif
import eif as iso_eif
import iso_forest as iso_if
import vnif as iso_vnif
import HS_Tree as iso_HS
import HS_Tree_vnif as iso_HS_vnif
mean = [0, 0]
cov = [[1, 0], [0, 1]]  # diagonal covariance
Nobjs = 2000

x, y = np.random.multivariate_normal(mean, cov, Nobjs).T
X=np.array([x,y]).T

S_vneif = []
S_eif   = []
S_if =[]
S_vnif = []
S_HS = []
S_HS_vnif =[]

ntrees=50
sample = 256
# vneif
time_start = time.time()
for n in range (0,100):
    CT = []
    for i in range(ntrees):
        ix = rn.sample(range(Nobjs),sample)
        X_p = X[ix]
        limit = 10
        C=iso_eif_vnif.iTree(X_p,0,limit)
        CT.append(C)
    S = np.zeros(Nobjs)
    c = iso_eif_vnif.c_factor(sample)
    for i in range(Nobjs):
        h_temp = 0
        for j in range(ntrees):
            h_temp += iso_eif_vnif.PathFactor(X[i]+i,CT[j]).path*1.0
        Eh = h_temp/ntrees
        S[i] = 2.0**(-Eh/c)
    S_vneif.append(S)
time_end = time.time()
print('vneif cost: ',time_end-time_start)
# vneif finished

# eif
time_start = time.time()
for n in range (0,100):
    CT = []
    for i in range(ntrees):
        ix = rn.sample(range(Nobjs),sample)
        X_p = X[ix]
        limit = 10
        C=iso_eif.iTree(X_p,0,limit)
        CT.append(C)
    S = np.zeros(Nobjs)
    c = iso_eif.c_factor(sample)
    for i in range(Nobjs):
        h_temp = 0
        for j in range(ntrees):
            h_temp += iso_eif.PathFactor(X[i]+i,CT[j]).path*1.0
        Eh = h_temp/ntrees
        S[i] = 2.0**(-Eh/c)
    S_eif.append(S)
time_end = time.time()
print('eif cost: ',time_end-time_start)
# eif finished

# if
time_start = time.time()
for n in range (0,100):
    CT = []
    for i in range(ntrees):
        ix = rn.sample(range(Nobjs),sample)
        X_p = X[ix]
        limit = 10
        C=iso_if.iTree(X_p,0,limit)
        CT.append(C)
    S = np.zeros(Nobjs)
    c = iso_if.c_factor(sample)
    for i in range(Nobjs):
        h_temp = 0
        for j in range(ntrees):
            h_temp += iso_if.PathFactor(X[i]+i,CT[j]).path*1.0
        Eh = h_temp/ntrees
        S[i] = 2.0**(-Eh/c)
    S_if.append(S)
time_end = time.time()
print('if cost: ',time_end-time_start)
# if finished

# vnif
time_start = time.time()
for n in range (0,100):
    CT = []
    for i in range(ntrees):
        ix = rn.sample(range(Nobjs),sample)
        X_p = X[ix]
        limit = 10
        C=iso_vnif.iTree(X_p,0,limit)
        CT.append(C)
    S = np.zeros(Nobjs)
    c = iso_eif_vnif.c_factor(sample)
    for i in range(Nobjs):
        h_temp = 0
        for j in range(ntrees):
            h_temp += iso_vnif.PathFactor(X[i]+i,CT[j]).path*1.0
        Eh = h_temp/ntrees
        S[i] = 2.0**(-Eh/c)
    S_vnif.append(S)
time_end = time.time()
print('vnif cost: ',time_end-time_start)
# vnif finished

# HS_Tree
time_start = time.time()
for n in range (0,100):
    CT = []
    for i in range(ntrees):
        ix = rn.sample(range(Nobjs),sample)
        X_p = X[ix]
        limit = 10
        C=iso_HS.iTree(X_p,0,limit)
        CT.append(C)
    S = np.zeros(Nobjs)
    c = iso_HS.c_factor(sample)
    for i in range(Nobjs):
        h_temp = 0
        for j in range(ntrees):
            h_temp += iso_HS.PathFactor(X[i]+i,CT[j]).path*1.0
        Eh = h_temp/ntrees
        S[i] = 2.0**(-Eh/c)
    S_HS.append(S)
time_end = time.time()
print('HS-Tree cost: ',time_end-time_start)
# HS-Tree finished

# HS_Tree_vnif
time_start = time.time()
for n in range (0,100):
    CT = []
    for i in range(ntrees):
        ix = rn.sample(range(Nobjs),sample)
        X_p = X[ix]
        limit = 10
        C=iso_HS_vnif.iTree(X_p,0,limit)
        CT.append(C)
    S = np.zeros(Nobjs)
    c = iso_HS_vnif.c_factor(sample)
    for i in range(Nobjs):
    #for i in range(2):
        h_temp = 0
        for j in range(ntrees):
            h_temp += iso_HS_vnif.PathFactor(X[i]+i,CT[j]).path*1.0
        Eh = h_temp/ntrees
        S[i] = 2.0**(-Eh/c)
    S_HS_vnif.append(S)
time_end = time.time()
print('HS-Tree_vnif cost: ',time_end-time_start)

S_vneif_pd = DataFrame(S_vneif)
S_eif_pd = DataFrame(S_eif)
S_if_pd = DataFrame(S_if)
S_vnif_pd = DataFrame(S_vnif)
S_HS_pd = DataFrame(S_HS)
S_HS_vnif_pd = DataFrame(S_HS_vnif)

S_vneif_mean = S_vneif_pd.mean(axis=0)
S_eif_mean = S_eif_pd.mean(axis=0)
S_if_mean = S_if_pd.mean(axis=0)
S_vnif_mean = S_vnif_pd.mean(axis=0)
S_HS_mean = S_HS_pd.mean(axis=0)
S_HS_vnif_mean = S_HS_vnif_pd.mean(axis=0)

S_vneif_var = S_vneif_pd.var(axis=0)
S_eif_var = S_eif_pd.var(axis=0)
S_if_var = S_if_pd.var(axis=0)
S_vnif_var = S_vnif_pd.var(axis=0)
S_HS_var = S_HS_pd.var(axis=0)
S_HS_vnif_var = S_HS_vnif_pd.var(axis=0)

score = pd.concat([S_vneif_mean,S_vneif_var,S_eif_mean,S_eif_var,S_if_mean,S_if_var,S_vnif_mean,S_vnif_var,S_HS_mean,S_HS_var,S_HS_vnif_mean,S_HS_vnif_var],axis=1)
score.to_csv('score.csv')